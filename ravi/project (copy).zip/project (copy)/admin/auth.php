<?php
include("../db.php");
$u = $_POST['username'];
$p = $_POST['password'];

// $p = ($p);

 $query = "SELECT * FROM admin_table WHERE user_name='$u'";
$result=mysqli_query($con, $query);
	// print_r($result);die;
if(mysqli_num_rows($result)==1)
{
	$data = mysqli_fetch_assoc($result);
	if($data['password']==$p)
	{
		$_SESSION['id']=$data['id'];
		$_SESSION['is_admin_logged_in']=true;
		header("location:dashboard.php");
	}
	else
	{
		$_SESSION['msg']= "This Password is Incorrect !";
		header("location:index.php");
	}
}
else
{
	$_SESSION['msg']= "This Username And Password is Incorrect !";
	header("location:index.php");
}


?>