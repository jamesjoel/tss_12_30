<div class="conatiner-fluid my-dark pt-5">
	<div class="container pt-5">
		<div class="row">
			<div class="col-md-3 text-light">
				<h4>My Shopping Site</h4>
				<p>301, Gold Star Tower, M. G. Road, Indore <br /><i class="fa fa-phone" aria-hidden="true"></i> 9893630582</p>

			</div>
			<div class="col-md-2">
				<ul class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">About</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Contact</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Help</a>
					</li>
				</ul>
			</div>
			<div class="col-md-2">
				<ul class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">About</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Contact</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Help</a>
					</li>
				</ul>
			</div>
			<div class="col-md-5">
				<form>
					<div class="row">
						<div class="form-group col-md-6">
							<input type="text" placeholder="Full Name" class="form-control">
						</div>
						<div class="form-group col-md-6">
							<input type="text" placeholder="Contact" class="form-control">
						</div>
						<div class="form-group col-md-12">
							<textarea class="form-control" placeholder="Message"></textarea>
						</div>

					</div>
					<button class="btn btn-primary">Send</button>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>
