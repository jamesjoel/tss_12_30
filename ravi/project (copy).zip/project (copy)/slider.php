<div class="jumbotron jumbotron-fluid slider-bg">
</div>
<div class="conatiner-fluid mb-4 pb-4">
	<div class="container">
		<h1 class="display-4 text-center">
			Premium Product
		</h1>
		<p class="text-center text-muted h3">
			We recommend
		</p>
	</div>
</div>