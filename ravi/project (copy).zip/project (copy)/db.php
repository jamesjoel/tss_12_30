<?php

$con = mysqli_connect("localhost", "root", "password", "user");
session_start();
?>